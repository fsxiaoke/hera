define("config.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

/**
 * 小程序配置文件
 */

// 此处主机域名是腾讯云解决方案分配的域名
// 小程序后台服务解决方案：https://www.qcloud.com/solution/la

var host = '14592619.qcloud.la';

var config = {
  // 下面的地址配合云端 Server 工作
  host: host,

  // 登录地址，用于建立会话
  loginUrl: 'https://' + host + '/login',

  // 测试的请求地址，用于测试会话
  requestUrl: 'https://' + host + '/testRequest',

  // 用code换取openId
  openIdUrl: 'https://' + host + '/openid',

  // 测试的信道服务接口
  tunnelUrl: 'https://' + host + '/tunnel',

  // 生成支付订单的接口
  paymentUrl: 'https://' + host + '/payment',

  // 发送模板消息接口
  templateMessageUrl: 'https://' + host + '/templateMessage',

  // 上传文件接口
  uploadFileUrl: 'https://' + host + '/upload',

  // 下载示例图片接口
  downloadExampleUrl: 'https://' + host + '/static/weapp.jpg'
};

module.exports = config;
});
define("lib/src/api/config/config.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Config = function () {
  function Config() {
    _classCallCheck(this, Config);
  }

  _createClass(Config, [{
    key: 'init',
    value: function init() {
      var _this = this;

      return this.getFsInfo().then(function () {
        return _this.getSystemInfo();
      });
    }
  }, {
    key: 'getFsInfo',
    value: function getFsInfo() {
      var _this2 = this;

      return new Promise(function (resolve) {
        var self = _this2;
        wx.getFsInfo({
          success: function success(res) {
            self.fsInfo = res || '';
            resolve(res);
          }
        });
      });
    }
  }, {
    key: 'getSystemInfo',
    value: function getSystemInfo() {
      var _this3 = this;

      return new Promise(function (resolve) {
        var self = _this3;
        wx.getSystemInfo({
          success: function success(res) {
            self.systemInfo = res || '';
            resolve(res);
          }
        });
      });
    }
  }]);

  return Config;
}();

exports.default = new Config();
});
define("lib/src/api/config/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _config = require('./config');

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _config2.default;
});
define("lib/src/api/http/http.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _index = require('../config/index');

var _index2 = _interopRequireDefault(_index);

var _utils = require('../utils.js');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Http = function () {
  function Http() {
    _classCallCheck(this, Http);
  }

  _createClass(Http, [{
    key: 'get',
    value: function get(params) {
      params.method = 'GET';
      this.request(params);
    }
  }, {
    key: 'post',
    value: function post(params) {
      params.method = 'POST';
      this.request(params);
    }
  }, {
    key: 'request',
    value: function request(params) {
      var _params = params;
      if ((0, _utils.isNeedApiPrefix)(_params.url)) {
        _params.url = '' + _index2.default.fsInfo.host + _params.url;
        _params.url = _params.url + '/' + _index2.default.systemInfo.platform + '.' + _index2.default.fsInfo.versionCode + '?_pid=' + (0, _utils.uuid)() + '&traceId=E-' + _index2.default.fsInfo.enterpriseAccount + '.' + _index2.default.fsInfo.employeeID + '-' + (0, _utils.uuid)() + '&_vn=' + _index2.default.fsInfo.versionCode + '&versionName=' + _index2.default.fsInfo.versionName + '&_postid=' + (0, _utils.uuid)();
      }
      _params.header = _extends({
        'accept-language': this.getAcceptLang(),
        cookie: _index2.default.fsInfo.cookie,
        Accept: 'application/json',
        'Content-Type': 'application/json; charset=UTF-8'
      }, _params.header || {});

      wx.request(_params);
    }
  }, {
    key: 'getAcceptLang',
    value: function getAcceptLang() {
      var locale = _index2.default.fsInfo.language;
      switch (locale) {
        case 'zh-CN':
          return 'zh-CN,zh-TW;0.9,en;0.8';
          break;
        case 'en':
          return 'en,zh-CN;0.9,zh-TW;0.8';
          break;
        case 'zh-TW':
          return 'zh-TW,zh-CN;0.9,en;0.8';
          break;
        default:
          return 'zh-CN,zh-TW;0.9,en;0.8';
      }
    }
  }]);

  return Http;
}();

exports.default = new Http();
});
define("lib/src/api/http/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _http = require('./http');

var _http2 = _interopRequireDefault(_http);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _http2.default;
});
define("lib/src/api/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _index = require('./config/index');

var _index2 = _interopRequireDefault(_index);

var _index3 = require('./http/index');

var _index4 = _interopRequireDefault(_index3);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  config: _index2.default,
  http: _index4.default
};
});
define("lib/src/api/utils.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

exports.isNeedApiPrefix = isNeedApiPrefix;
exports.uuid = uuid;
exports.replaceAll = replaceAll;
exports.i18nFormat = i18nFormat;
exports.getCookie = getCookie;
function isNeedApiPrefix(url) {
  return !/^(https?\:\/\/)|^(\/\/)/.test(url);
}

function uuid() {
  var s = [];
  var hexDigits = '0123456789abcdef';
  for (var i = 0; i < 36; i++) {
    s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
  }
  s[14] = '4'; // bits 12-15 of the time_hi_and_version field to 0010
  s[19] = hexDigits.substr(s[19] & 0x3 | 0x8, 1); // bits 6-7 of the clock_seq_hi_and_reserved to 01
  s[8] = s[13] = s[18] = s[23] = '-';

  var uuid = s.join('');

  return replaceAll(uuid, '-', '');
}

function replaceAll(str, ov, nv) {
  return str.replace(new RegExp(ov, 'gm'), nv);
}

function i18nFormat(txt, args) {
  if (args.length == 0) return txt;
  var param = args[0];
  var s = txt;
  if ((typeof param === 'undefined' ? 'undefined' : _typeof(param)) === 'object') {
    for (var key in param) {
      s = s.replace(new RegExp('\\{' + key + '\\}', 'g'), param[key]);
    }
    return s;
  } else {
    for (var i = 0; i < args.length; i++) {
      s = s.replace(new RegExp('\\{' + i + '\\}', 'g'), args[i]);
    }
    return s;
  }
}

function getCookie(cookieName) {
  var strCookie = document.cookie;
  var arrCookie = strCookie.split(';');
  for (var i = 0; i < arrCookie.length; i++) {
    var arr = arrCookie[i].split('=');
    if (cookieName == arr[0].trim()) {
      return arr[1];
    }
  }
  return '';
}
});
define("util/util.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

function formatTime(time) {
  if (typeof time !== 'number' || time < 0) {
    return time;
  }

  var hour = parseInt(time / 3600);
  time = time % 3600;
  var minute = parseInt(time / 60);
  time = time % 60;
  var second = time;

  return [hour, minute, second].map(function (n) {
    n = n.toString();
    return n[1] ? n : '0' + n;
  }).join(':');
}

function formatLocation(longitude, latitude) {
  if (typeof longitude === 'string' && typeof latitude === 'string') {
    longitude = parseFloat(longitude);
    latitude = parseFloat(latitude);
  }

  longitude = longitude.toFixed(2);
  latitude = latitude.toFixed(2);

  return {
    longitude: longitude.toString().split('.'),
    latitude: latitude.toString().split('.')
  };
}

module.exports = {
  formatTime: formatTime,
  formatLocation: formatLocation
};
});
define("app.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _index = require('./lib/src/api/index');

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var openIdUrl = require('./config').openIdUrl;


App({
  onLaunch: function onLaunch() {
    console.log('App Launch');
    _index2.default.config.init();
  },
  onShow: function onShow() {
    console.log('App Show');
  },
  onHide: function onHide() {
    console.log('App Hide');
  },
  globalData: {
    hasLogin: false,
    openid: null
  },

  // lazy loading openid
  getUserOpenId: function getUserOpenId(callback) {
    var self = this;

    if (self.globalData.openid) {
      callback(null, self.globalData.openid);
    } else {
      wx.login({
        success: function success(data) {
          wx.request({
            url: openIdUrl,
            data: {
              code: data.code
            },
            success: function success(res) {
              console.log('拉取openid成功', res);
              self.globalData.openid = res.data.openid;
              callback(null, self.globalData.openid);
            },
            fail: function fail(res) {
              console.log('拉取用户openid失败，将无法正常使用开放接口等服务', res);
              callback(res);
            }
          });
        },
        fail: function fail(err) {
          console.log('wx.login 接口调用失败，将无法正常使用开放接口等服务', err);
          callback(err);
        }
      });
    }
  }
});
});require("app.js")
var __wxRoute = "page/view/button", __wxRouteBegin = true;
define("page/view/button.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  ontap: function ontap(e) {
    console.log('tap');

    wx.navigateTo({
      url: './button2',
      success: function success(result) {},
      fail: function fail() {},
      complete: function complete() {}
    });
  }
});
});require("page/view/button.js")
var __wxRoute = "page/view/button2", __wxRouteBegin = true;
define("page/view/button2.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

Page({
  ontap: function ontap(e) {
    console.log('tap');

    wx.navigateTo({
      url: './view',
      success: function success(result) {},
      fail: function fail() {},
      complete: function complete() {}
    });
  }
});
});require("page/view/button2.js")
var __wxRoute = "page/view/view", __wxRouteBegin = true;
define("page/view/view.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,fetch,XMLHttpRequest,WebSocket,webkit,WeixinJSCore,HeraJSCore,HeraJSBridge,Reporter){
'use strict';

var _index = require('../../lib/src/api/index');

var _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

Page({
  onHttp: function onHttp(event) {
    var self = this;
    _index2.default.http.post({
      url: '/FHE/EM1ANCRM/API/v1/object/object_ti13X__c/controller/NewDetail',
      data: {
        describeVersionMap: { object_ti13X__c: 210 },
        objectDataId: '5ea807346d3c320001d9d437',
        objectDescribeApiName: 'object_ti13X__c'
      },
      success: function success(result) {
        self.setData({ text: 'statusCode:' + result.statusCode });
        // wx.showToast({
        //   title: '请求成功' + JSON.stringify(result),
        //   icon: 'success',
        //   mask: true,
        //   duration: 2000
        // })

        console.log('request success', result);
      },

      fail: function fail(_ref) {
        var errMsg = _ref.errMsg;

        wx.showToast({
          title: '请求失败' + errMsg,
          icon: 'fail',
          mask: true,
          duration: 2000
        });
        console.log('request fail', errMsg);
      }
    });
  },

  navigateBack1: function navigateBack1(event) {
    wx.navigateBack({ delta: 1 });
  },
  navigateBack2: function navigateBack2(event) {
    wx.navigateBack({ delta: 2 });
  },
  data: {
    text: 'This is page data.'
  },
  onLoad: function onLoad(options) {
    // Do some initialize when page load.
  },
  onShow: function onShow() {
    // Do something when page show.
  },
  onReady: function onReady() {
    // var self = this
    // self.setData({ text: JSON.stringify(api.config.fsInfo)+"\n"+JSON.stringify(api.config.systemInfo) })
    // Do something when page ready.
  },
  onHide: function onHide() {
    // Do something when page hide.
  },
  onUnload: function onUnload() {
    // Do something when page close.
  },
  onPullDownRefresh: function onPullDownRefresh() {
    // Do something when pull down.
  },
  onReachBottom: function onReachBottom() {
    // Do something when page reach bottom.
  },
  onShareAppMessage: function onShareAppMessage() {
    // return custom share data when user share.
  },
  onPageScroll: function onPageScroll() {
    // Do something when page scroll
  },
  onResize: function onResize() {
    // Do something when page resize
  },
  onTabItemTap: function onTabItemTap(item) {
    console.log(item.index);
    console.log(item.pagePath);
    console.log(item.text);
  },

  // Event handler.
  viewTap: function viewTap() {
    this.setData({
      text: 'Set some data for updating view.'
    }, function () {
      // this is setData callback
    });
  },
  customData: {
    hi: 'MINA'
  }
});
});require("page/view/view.js")